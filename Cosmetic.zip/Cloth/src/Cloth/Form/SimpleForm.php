<?php

declare(strict_types=1);

namespace Cloth\Form;

use Closure;
use pocketmine\form\Form;
use pocketmine\form\FormValidationException;
use pocketmine\player\Player;

final class SimpleForm implements Form{

	private array $buttons = [];
	private ?Closure $onClose = null;

	public function __construct(private string $title, private string $content = ""){}

	public function addButton(string $text, Closure $onClick) : self{
		$this->buttons[] = ["text" => $text, "cb" => $onClick];
		return $this;
	}

	public function onClose(Closure $callback) : self{
		$this->onClose = $callback;
		return $this;
	}

	public function jsonSerialize() : array{
		$buttons = [];
		foreach($this->buttons as $b){
			$buttons[] = ["text" => $b["text"]];
		}
		return [
			"type" => "form",
			"title" => $this->title,
			"content" => $this->content,
			"buttons" => $buttons
		];
	}

	public function handleResponse(Player $player, $data) : void{
		if($data === null){
			if($this->onClose !== null){
				($this->onClose)($player);
			}
			return;
		}
		if(!is_int($data) || !isset($this->buttons[$data])){
			throw new FormValidationException("Invalid button index");
		}
		($this->buttons[$data]["cb"])($player);
	}
}
