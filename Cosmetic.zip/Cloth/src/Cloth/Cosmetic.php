<?php

declare(strict_types=1);

namespace Cloth;

final class Cosmetic{

	public function __construct(
		public readonly string $category,
		public readonly string $id,
		public readonly string $name,
		public readonly string $rgba,
		public readonly int $width,
		public readonly int $height,
		public readonly string $geometryName = "",
		public readonly string $geometryData = ""
	){}
}
