<?php

declare(strict_types=1);

namespace Cloth;

use InvalidArgumentException;
use pocketmine\entity\Skin;
use pocketmine\player\Player;
use pocketmine\utils\Config;

final class CosmeticManager{

	public const CATEGORIES = ["wings", "3d", "capes"];

	private array $items = ["wings" => [], "3d" => [], "capes" => []];
	private array $originals = [];
	private Config $data;

	public function __construct(private Main $plugin){
		$this->data = new Config($plugin->getDataFolder() . "players.json", Config::JSON);
	}

	public function load() : int{
		$total = 0;
		$names = (array) $this->plugin->getConfig()->get("names", []);
		foreach(self::CATEGORIES as $category){
			$this->items[$category] = [];
			$dir = $this->plugin->getDataFolder() . $category . DIRECTORY_SEPARATOR;
			$files = glob($dir . "*.png") ?: [];
			sort($files);
			foreach($files as $png){
				$id = pathinfo($png, PATHINFO_FILENAME);
				$custom = $names[$category][$id] ?? null;
				$name = is_string($custom) ? $custom : ucwords(str_replace(["_", "-"], " ", $id));
				$item = $category === "capes"
					? $this->loadCape($png, $id, $name)
					: $this->loadModel($category, $dir, $id, $name);
				if($item !== null){
					$this->items[$category][$id] = $item;
					$total++;
				}
			}
		}
		return $total;
	}

	private function loadCape(string $png, string $id, string $name) : ?Cosmetic{
		$image = self::readPng($png);
		if($image === null){
			$this->plugin->getLogger()->warning("Could not read cape " . $id);
			return null;
		}
		[$w, $h, $rgba] = $image;
		$rgba = self::resize($rgba, $w, $h, 64, 32);
		return new Cosmetic("capes", $id, $name, $rgba, 64, 32);
	}

	private function loadModel(string $category, string $dir, string $id, string $name) : ?Cosmetic{
		$png = $dir . $id . ".png";
		$jsonPath = $dir . $id . ".json";
		if(!is_file($jsonPath)){
			$this->plugin->getLogger()->warning("Missing geometry file for " . $category . "/" . $id);
			return null;
		}
		$image = self::readPng($png);
		if($image === null){
			$this->plugin->getLogger()->warning("Could not read texture " . $category . "/" . $id);
			return null;
		}
		[$w, $h, $rgba] = $image;
		if($w === 64 && $h === 32){
			$rgba .= str_repeat("\x00", 64 * 32 * 4);
			$h = 64;
		}
		if(!(($w === 64 && $h === 64) || ($w === 128 && $h === 128))){
			$this->plugin->getLogger()->warning("Texture " . $category . "/" . $id . " must be 64x64 or 128x128");
			return null;
		}
		$json = file_get_contents($jsonPath);
		$geometryName = $json === false ? null : self::geometryName($json);
		if($json === false || $geometryName === null){
			$this->plugin->getLogger()->warning("Invalid geometry file for " . $category . "/" . $id);
			return null;
		}
		return new Cosmetic($category, $id, $name, $rgba, $w, $h, $geometryName, $json);
	}

	private static function geometryName(string $json) : ?string{
		$data = json_decode($json, true);
		if(!is_array($data)){
			return null;
		}
		$identifier = $data["minecraft:geometry"][0]["description"]["identifier"] ?? null;
		if(is_string($identifier)){
			return $identifier;
		}
		foreach(array_keys($data) as $key){
			if(is_string($key) && str_starts_with($key, "geometry.")){
				return explode(":", $key)[0];
			}
		}
		return null;
	}

	private static function readPng(string $path) : ?array{
		$image = @imagecreatefrompng($path);
		if($image === false){
			return null;
		}
		if(!imageistruecolor($image)){
			imagepalettetotruecolor($image);
		}
		$w = imagesx($image);
		$h = imagesy($image);
		$parts = [];
		for($y = 0; $y < $h; $y++){
			for($x = 0; $x < $w; $x++){
				$c = imagecolorat($image, $x, $y);
				$alpha = 255 - (int) round((($c >> 24) & 0x7F) * 255 / 127);
				$parts[] = chr(($c >> 16) & 0xFF) . chr(($c >> 8) & 0xFF) . chr($c & 0xFF) . chr($alpha);
			}
		}
		imagedestroy($image);
		return [$w, $h, implode("", $parts)];
	}

	private static function resize(string $rgba, int $w, int $h, int $nw, int $nh) : string{
		if($w === $nw && $h === $nh){
			return $rgba;
		}
		$parts = [];
		for($y = 0; $y < $nh; $y++){
			$sy = intdiv($y * $h, $nh);
			for($x = 0; $x < $nw; $x++){
				$sx = intdiv($x * $w, $nw);
				$parts[] = substr($rgba, ($sy * $w + $sx) * 4, 4);
			}
		}
		return implode("", $parts);
	}

	private static function merge(string $base, Cosmetic $cosmetic) : string{
		[$bw, $bh] = match(strlen($base)){
			8192 => [64, 32],
			65536 => [128, 128],
			default => [64, 64]
		};
		if($bh === 32){
			$base .= str_repeat("\x00", 64 * 32 * 4);
			$bh = 64;
		}
		$tw = max($bw, $cosmetic->width);
		$th = max($bh, $cosmetic->height);
		$out = self::resize($base, $bw, $bh, $tw, $th);
		$over = self::resize($cosmetic->rgba, $cosmetic->width, $cosmetic->height, $tw, $th);
		$count = $tw * $th;
		for($i = 0; $i < $count; $i++){
			$o = $i * 4;
			$a = ord($over[$o + 3]);
			if($a === 0){
				continue;
			}
			if($a === 255){
				$out[$o] = $over[$o];
				$out[$o + 1] = $over[$o + 1];
				$out[$o + 2] = $over[$o + 2];
				$out[$o + 3] = "\xFF";
				continue;
			}
			$inv = 255 - $a;
			for($k = 0; $k < 3; $k++){
				$out[$o + $k] = chr((int) ((ord($over[$o + $k]) * $a + ord($out[$o + $k]) * $inv) / 255));
			}
			$out[$o + 3] = chr(max(ord($out[$o + 3]), $a));
		}
		return $out;
	}

	public function getItems(string $category) : array{
		return $this->items[$category] ?? [];
	}

	private function key(Player $player) : string{
		return strtolower($player->getName());
	}

	public function getState(Player $player) : array{
		$state = $this->data->get($this->key($player), []);
		return is_array($state) ? $state : [];
	}

	private function setState(Player $player, array $state) : void{
		$this->data->set($this->key($player), $state);
		$this->data->save();
	}

	public function canUse(Player $player, string $category, string $id) : bool{
		if(!$this->plugin->getConfig()->get("permissions-enabled", false)){
			return true;
		}
		if($player->hasPermission("cloth.admin")){
			return true;
		}
		$base = "cloth.use." . $category . ".";
		return $player->hasPermission($base . strtolower($id)) || $player->hasPermission($base . "*");
	}

	public function isActive(Player $player, Cosmetic $cosmetic) : bool{
		$state = $this->getState($player);
		if($cosmetic->category === "capes"){
			return ($state["cape"] ?? null) === $cosmetic->id;
		}
		return ($state["model"] ?? null) === $cosmetic->category . "/" . $cosmetic->id;
	}

	public function toggle(Player $player, Cosmetic $cosmetic) : bool{
		$state = $this->getState($player);
		$active = $this->isActive($player, $cosmetic);
		if($cosmetic->category === "capes"){
			if($active){
				unset($state["cape"]);
			}else{
				$state["cape"] = $cosmetic->id;
			}
		}else{
			if($active){
				unset($state["model"]);
			}else{
				$state["model"] = $cosmetic->category . "/" . $cosmetic->id;
			}
		}
		$this->setState($player, $state);
		$this->apply($player);
		return !$active;
	}

	public function removeCategory(Player $player, string $category) : void{
		$state = $this->getState($player);
		if($category === "capes"){
			unset($state["cape"]);
		}elseif(str_starts_with((string) ($state["model"] ?? ""), $category . "/")){
			unset($state["model"]);
		}
		$this->setState($player, $state);
		$this->apply($player);
	}

	public function clearAll(Player $player) : void{
		$this->setState($player, []);
		$this->apply($player);
	}

	public function getParticleId(Player $player) : ?string{
		$id = $this->getState($player)["particle"] ?? null;
		return is_string($id) ? $id : null;
	}

	public function setParticle(Player $player, ?string $id) : void{
		$state = $this->getState($player);
		if($id === null){
			unset($state["particle"]);
		}else{
			$state["particle"] = $id;
		}
		$this->setState($player, $state);
	}

	public function setOriginal(Player $player, Skin $skin) : void{
		$this->originals[$this->key($player)] = $skin;
	}

	public function onQuit(Player $player) : void{
		unset($this->originals[$this->key($player)]);
	}

	public function apply(Player $player) : void{
		if(!$player->isOnline()){
			return;
		}
		$original = $this->originals[$this->key($player)] ?? null;
		if($original === null){
			return;
		}
		$state = $this->getState($player);
		$skinData = $original->getSkinData();
		$capeData = $original->getCapeData();
		$geometryName = $original->getGeometryName();
		$geometryData = $original->getGeometryData();
		$changed = false;

		$model = null;
		$modelKey = $state["model"] ?? null;
		if(is_string($modelKey) && ($pos = strpos($modelKey, "/")) !== false){
			$model = $this->items[substr($modelKey, 0, $pos)][substr($modelKey, $pos + 1)] ?? null;
		}
		if($model !== null){
			$skinData = self::merge($skinData, $model);
			$geometryName = $model->geometryName;
			$geometryData = $model->geometryData;
			$changed = true;
		}

		$capeId = $state["cape"] ?? null;
		if(is_string($capeId) && isset($this->items["capes"][$capeId])){
			$capeData = $this->items["capes"][$capeId]->rgba;
			$changed = true;
		}

		try{
			$skin = $changed
				? new Skin($original->getSkinId() . "_cloth_" . substr(md5($skinData . $capeData . $geometryName), 0, 10), $skinData, $capeData, $geometryName, $geometryData)
				: $original;
			$player->setSkin($skin);
			$player->sendSkin();
		}catch(InvalidArgumentException $e){
			$this->plugin->getLogger()->warning("Could not apply skin for " . $player->getName() . ": " . $e->getMessage());
		}
	}

	public function save() : void{
		$this->data->save();
	}
}
