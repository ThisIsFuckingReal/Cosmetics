<?php

declare(strict_types=1);

namespace Cloth;

use Closure;
use pocketmine\color\Color;
use pocketmine\world\particle\AngryVillagerParticle;
use pocketmine\world\particle\BubbleParticle;
use pocketmine\world\particle\CriticalParticle;
use pocketmine\world\particle\DustParticle;
use pocketmine\world\particle\EnchantmentTableParticle;
use pocketmine\world\particle\EntityFlameParticle;
use pocketmine\world\particle\FlameParticle;
use pocketmine\world\particle\HappyVillagerParticle;
use pocketmine\world\particle\HeartParticle;
use pocketmine\world\particle\InkParticle;
use pocketmine\world\particle\LavaParticle;
use pocketmine\world\particle\Particle;
use pocketmine\world\particle\PortalParticle;
use pocketmine\world\particle\RedstoneParticle;
use pocketmine\world\particle\SmokeParticle;
use pocketmine\world\particle\WaterParticle;

final class Particles{

	private static ?array $registry = null;

	public static function all() : array{
		return self::$registry ??= [
			"flame" => ["Flame", static fn() => new FlameParticle()],
			"heart" => ["Hearts", static fn() => new HeartParticle()],
			"smoke" => ["Smoke", static fn() => new SmokeParticle()],
			"lava" => ["Lava", static fn() => new LavaParticle()],
			"water" => ["Water Drops", static fn() => new WaterParticle()],
			"portal" => ["Portal", static fn() => new PortalParticle()],
			"critical" => ["Critical", static fn() => new CriticalParticle()],
			"enchant" => ["Enchant", static fn() => new EnchantmentTableParticle()],
			"happy" => ["Happy Villager", static fn() => new HappyVillagerParticle()],
			"angry" => ["Angry Villager", static fn() => new AngryVillagerParticle()],
			"bubble" => ["Bubbles", static fn() => new BubbleParticle()],
			"ink" => ["Ink", static fn() => new InkParticle()],
			"redstone" => ["Redstone", static fn() => new RedstoneParticle()],
			"entity_flame" => ["Blue Flame", static fn() => new EntityFlameParticle()],
			"rainbow" => ["Rainbow Dust", static fn() => new DustParticle(new Color(random_int(0, 255), random_int(0, 255), random_int(0, 255)))],
		];
	}

	public static function create(string $id) : ?Particle{
		$entry = self::all()[$id] ?? null;
		return $entry === null ? null : ($entry[1])();
	}

	public static function name(string $id) : ?string{
		return self::all()[$id][0] ?? null;
	}
}
