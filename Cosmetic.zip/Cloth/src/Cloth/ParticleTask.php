<?php

declare(strict_types=1);

namespace Cloth;

use pocketmine\scheduler\Task;
use pocketmine\Server;

final class ParticleTask extends Task{

	public function __construct(private CosmeticManager $manager, private int $count){}

	public function onRun() : void{
		foreach(Server::getInstance()->getOnlinePlayers() as $player){
			$id = $this->manager->getParticleId($player);
			if($id === null || !$player->isAlive() || $player->isSpectator()){
				continue;
			}
			$pos = $player->getPosition();
			$world = $pos->getWorld();
			for($i = 0; $i < $this->count; $i++){
				$particle = Particles::create($id);
				if($particle === null){
					break;
				}
				$world->addParticle(
					$pos->add((lcg_value() - 0.5) * 0.9, lcg_value() * 1.7, (lcg_value() - 0.5) * 0.9),
					$particle
				);
			}
		}
	}
}
