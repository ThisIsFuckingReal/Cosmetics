<?php

declare(strict_types=1);

namespace Cloth;

use Cloth\Form\SimpleForm;
use pocketmine\player\Player;

final class Menu{

	public function __construct(private Main $plugin, private CosmeticManager $manager){}

	private function msg(Player $player, string $text) : void{
		$player->sendMessage($this->plugin->tr("prefix") . $text);
	}

	public function main(Player $player) : void{
		$form = new SimpleForm($this->plugin->tr("title-main"), $this->plugin->tr("content-main"));
		$form->addButton($this->plugin->tr("btn-wings"), fn(Player $p) => $this->category($p, "wings"));
		$form->addButton($this->plugin->tr("btn-3d"), fn(Player $p) => $this->category($p, "3d"));
		$form->addButton($this->plugin->tr("btn-capes"), fn(Player $p) => $this->category($p, "capes"));
		$form->addButton($this->plugin->tr("btn-particles"), fn(Player $p) => $this->particles($p));
		$form->addButton($this->plugin->tr("btn-clear"), function(Player $p) : void{
			$this->manager->clearAll($p);
			$this->manager->setParticle($p, null);
			$this->msg($p, $this->plugin->tr("cleared"));
		});
		$player->sendForm($form);
	}

	public function category(Player $player, string $category) : void{
		$items = $this->manager->getItems($category);
		$form = new SimpleForm($this->plugin->tr("title-" . $category), $items === [] ? $this->plugin->tr("empty") : "");
		$form->addButton($this->plugin->tr("btn-remove"), function(Player $p) use ($category) : void{
			$this->manager->removeCategory($p, $category);
			$this->msg($p, $this->plugin->tr("unequipped"));
			$this->category($p, $category);
		});
		foreach($items as $item){
			$allowed = $this->manager->canUse($player, $category, $item->id);
			$active = $this->manager->isActive($player, $item);
			$suffix = $active ? " §a✔" : ($allowed ? "" : " §c✖");
			$form->addButton($item->name . $suffix, function(Player $p) use ($item, $category) : void{
				if(!$this->manager->canUse($p, $category, $item->id)){
					$this->msg($p, $this->plugin->tr("no-permission"));
					return;
				}
				$on = $this->manager->toggle($p, $item);
				$this->msg($p, $on ? str_replace("{name}", $item->name, $this->plugin->tr("equipped")) : $this->plugin->tr("unequipped"));
				$this->category($p, $category);
			});
		}
		$form->addButton($this->plugin->tr("btn-back"), fn(Player $p) => $this->main($p));
		$player->sendForm($form);
	}

	public function particles(Player $player) : void{
		$form = new SimpleForm($this->plugin->tr("title-particles"));
		$form->addButton($this->plugin->tr("btn-remove"), function(Player $p) : void{
			$this->manager->setParticle($p, null);
			$this->msg($p, $this->plugin->tr("unequipped"));
			$this->particles($p);
		});
		$disabled = (array) $this->plugin->getConfig()->getNested("particles.disabled", []);
		$current = $this->manager->getParticleId($player);
		foreach(Particles::all() as $id => $entry){
			if(in_array($id, $disabled, true)){
				continue;
			}
			$name = (string) $this->plugin->getConfig()->getNested("particle-names." . $id, $entry[0]);
			$allowed = $this->manager->canUse($player, "particles", $id);
			$suffix = $current === $id ? " §a✔" : ($allowed ? "" : " §c✖");
			$form->addButton($name . $suffix, function(Player $p) use ($id, $name) : void{
				if(!$this->manager->canUse($p, "particles", $id)){
					$this->msg($p, $this->plugin->tr("no-permission"));
					return;
				}
				if($this->manager->getParticleId($p) === $id){
					$this->manager->setParticle($p, null);
					$this->msg($p, $this->plugin->tr("unequipped"));
				}else{
					$this->manager->setParticle($p, $id);
					$this->msg($p, str_replace("{name}", $name, $this->plugin->tr("equipped")));
				}
				$this->particles($p);
			});
		}
		$form->addButton($this->plugin->tr("btn-back"), fn(Player $p) => $this->main($p));
		$player->sendForm($form);
	}
}
