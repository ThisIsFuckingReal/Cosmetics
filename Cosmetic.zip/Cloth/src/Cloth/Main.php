<?php

declare(strict_types=1);

namespace Cloth;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChangeSkinEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\scheduler\ClosureTask;

final class Main extends PluginBase implements Listener{

	private CosmeticManager $manager;
	private Menu $menu;

	protected function onEnable() : void{
		if(!extension_loaded("gd")){
			$this->getLogger()->critical("The GD PHP extension is required");
			$this->getServer()->getPluginManager()->disablePlugin($this);
			return;
		}
		$this->saveDefaultConfig();
		foreach($this->getResources() as $path => $file){
			$relative = str_replace("\\", "/", (string) $path);
			if($relative === "config.yml" || $file->isDir()){
				continue;
			}
			if(!is_file($this->getDataFolder() . $relative)){
				$this->saveResource($relative);
			}
		}
		foreach(CosmeticManager::CATEGORIES as $category){
			$dir = $this->getDataFolder() . $category;
			if(!is_dir($dir)){
				@mkdir($dir, 0777, true);
			}
		}
		$this->manager = new CosmeticManager($this);
		$count = $this->manager->load();
		$this->getLogger()->info("Loaded " . $count . " cosmetics");
		$this->menu = new Menu($this, $this->manager);
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$interval = max(1, (int) $this->getConfig()->get("particle-interval", 4));
		$amount = max(1, (int) $this->getConfig()->get("particle-count", 2));
		$this->getScheduler()->scheduleRepeatingTask(new ParticleTask($this->manager, $amount), $interval);
		foreach($this->getServer()->getOnlinePlayers() as $player){
			$this->manager->setOriginal($player, $player->getSkin());
			$this->manager->apply($player);
		}
	}

	protected function onDisable() : void{
		if(isset($this->manager)){
			$this->manager->save();
		}
	}

	public function tr(string $key) : string{
		return (string) $this->getConfig()->getNested("messages." . $key, $key);
	}

	public function onJoin(PlayerJoinEvent $event) : void{
		$player = $event->getPlayer();
		$this->manager->setOriginal($player, $player->getSkin());
		$this->getScheduler()->scheduleDelayedTask(new ClosureTask(function() use ($player) : void{
			$this->manager->apply($player);
		}), 20);
	}

	public function onQuit(PlayerQuitEvent $event) : void{
		$this->manager->onQuit($event->getPlayer());
	}

	public function onChangeSkin(PlayerChangeSkinEvent $event) : void{
		$player = $event->getPlayer();
		$this->manager->setOriginal($player, $event->getNewSkin());
		$this->getScheduler()->scheduleDelayedTask(new ClosureTask(function() use ($player) : void{
			$this->manager->apply($player);
		}), 2);
	}

	public function onCommand(CommandSender $sender, Command $command, string $label, array $args) : bool{
		$sub = strtolower($args[0] ?? "");
		if($sub === "reload"){
			if(!$sender->hasPermission("cloth.admin")){
				return true;
			}
			$this->reloadConfig();
			$count = $this->manager->load();
			foreach($this->getServer()->getOnlinePlayers() as $player){
				$this->manager->apply($player);
			}
			$sender->sendMessage($this->tr("prefix") . str_replace("{count}", (string) $count, $this->tr("reloaded")));
			return true;
		}
		if(!$sender instanceof Player){
			$sender->sendMessage($this->tr("ingame-only"));
			return true;
		}
		switch($sub){
			case "wings":
			case "3d":
			case "capes":
				$this->menu->category($sender, $sub);
				break;
			case "particles":
			case "particle":
				$this->menu->particles($sender);
				break;
			case "clear":
				$this->manager->clearAll($sender);
				$this->manager->setParticle($sender, null);
				$sender->sendMessage($this->tr("prefix") . $this->tr("cleared"));
				break;
			default:
				$this->menu->main($sender);
		}
		return true;
	}
}
